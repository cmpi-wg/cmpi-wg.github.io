var searchData=
[
  ['data_20types_20_28subclause_205_29',['Data Types (Subclause 5)',['../group__data-types.html',1,'']]]
];
