var searchData=
[
  ['version_5fmismatch',['Version_Mismatch',['../group__type-error-probable-cause.html#gga7bdea9e610f7ef0a598200e74131bd09a9a558b88f6fc9acca6185abc91f4b58f',1,'cmpidt.h']]]
];
