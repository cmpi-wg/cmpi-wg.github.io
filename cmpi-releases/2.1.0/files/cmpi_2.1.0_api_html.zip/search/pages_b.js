var searchData=
[
  ['required_20since_20cmpi_202_2e0',['Required since CMPI 2.0',['../required200.html',1,'']]],
  ['required_20since_20cmpi_202_2e1',['Required since CMPI 2.1',['../required210.html',1,'']]]
];
