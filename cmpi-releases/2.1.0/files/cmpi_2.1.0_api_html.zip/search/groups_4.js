var searchData=
[
  ['generic_20mi_20factory_20function',['Generic MI factory function',['../group__mi-factory-generic.html',1,'']]]
];
