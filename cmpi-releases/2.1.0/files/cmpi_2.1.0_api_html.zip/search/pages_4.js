var searchData=
[
  ['extended_20errors_20capability',['Extended Errors capability',['../caperrors.html',1,'']]]
];
