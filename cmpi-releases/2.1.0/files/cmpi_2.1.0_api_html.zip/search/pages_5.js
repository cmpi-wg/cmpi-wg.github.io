var searchData=
[
  ['indications_20capability',['Indications capability',['../capindications.html',1,'']]],
  ['instance_20manipulation_20capability',['Instance Manipulation capability',['../capmanipulation.html',1,'']]],
  ['incompatibilities_20in_20cmpi_202_2e1',['Incompatibilities in CMPI 2.1',['../incompatible210.html',1,'']]]
];
