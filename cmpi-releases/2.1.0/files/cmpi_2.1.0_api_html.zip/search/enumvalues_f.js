var searchData=
[
  ['qualityofserviceerror',['QualityOfServiceError',['../group__type-error-type.html#ggae96dacb0b6dd584d126fef6241779275a079340ab0b2f0d37b6ca6e6cd4237602',1,'cmpidt.h']]],
  ['queue_5fsize_5fexceeded',['Queue_Size_Exceeded',['../group__type-error-probable-cause.html#gga7bdea9e610f7ef0a598200e74131bd09afb6e1fdcb17ae790468d39e85f3ea722',1,'cmpidt.h']]]
];
