var searchData=
[
  ['codepage_20conversion_20capability',['Codepage Conversion capability',['../capcodepage.html',1,'']]],
  ['context_20data_20capability',['Context Data capability',['../capcontext.html',1,'']]],
  ['changed_20in_20cmpi_202_2e1',['Changed in CMPI 2.1',['../changed210.html',1,'']]],
  ['c_2fc_2b_2b_2dspecific_20definitions',['C/C++-specific Definitions',['../cxxspecific.html',1,'']]]
];
