var searchData=
[
  ['bug_20list',['Bug List',['../bug.html',1,'']]],
  ['basic_20qualifier_20capability',['Basic Qualifier capability',['../capqualifiers.html',1,'']]],
  ['basic_20read_20capability',['Basic Read capability',['../capread.html',1,'']]],
  ['basic_20write_20capability',['Basic Write capability',['../capwrite.html',1,'']]]
];
