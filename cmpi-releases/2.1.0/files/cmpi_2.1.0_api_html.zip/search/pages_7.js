var searchData=
[
  ['memory_20enhancement_20services_20capability',['Memory Enhancement Services capability',['../capmemory.html',1,'']]],
  ['message_20translation_20capability',['Message Translation capability',['../captranslation.html',1,'']]]
];
