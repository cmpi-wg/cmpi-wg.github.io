var searchData=
[
  ['prepareattachthread',['prepareAttachThread',['../group__broker-thread-reg.html#ga7e87b4dc8b08211c42b8efd4f27cf74c',1,'CMPIBrokerFT']]],
  ['ptr',['ptr',['../structCMPIValuePtr.html#ae7dbfdc79a6ee35693eb4149f11b46ef',1,'CMPIValuePtr']]]
];
