var searchData=
[
  ['property_20filtering_20capability',['Property Filtering capability',['../capfiltering.html',1,'']]],
  ['platform_2dspecific_20definitions',['Platform-specific Definitions',['../platformspecific.html',1,'']]]
];
