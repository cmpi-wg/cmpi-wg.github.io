var searchData=
[
  ['query_20execution_20capability',['Query Execution capability',['../capqueryexec.html',1,'']]],
  ['query_20normalization_20capability',['Query Normalization capability',['../capquerynorm.html',1,'']]]
];
