var searchData=
[
  ['os_20encapsulation_20services_20capability',['OS Encapsulation Services capability',['../capopsys.html',1,'']]]
];
