var searchData=
[
  ['logging_20capability',['Logging capability',['../caplogging.html',1,'']]]
];
