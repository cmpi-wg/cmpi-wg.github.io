var searchData=
[
  ['helper_20functions_20and_20macros',['Helper Functions and Macros',['../group__convenience-func-helper.html',1,'']]]
];
